package com.experts.mysql;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class UserInfoFragment extends Fragment {
    private View sView;
    private Bundle bundle;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        sView = inflater.inflate(R.layout.fragment_user_info, container, false);

        bundle = getArguments();
        findIds();


        return sView;
    }

    private void findIds() {
        TextView txtName = sView.findViewById(R.id.txtName);
        TextView txtPhone = sView.findViewById(R.id.txtPhone);
        TextView txtEmail = sView.findViewById(R.id.txtEmail);

        txtName.setText(bundle.get("name").toString());
        txtPhone.setText(bundle.get("phone").toString());
        txtEmail.setText(bundle.get("email").toString());
    }
}