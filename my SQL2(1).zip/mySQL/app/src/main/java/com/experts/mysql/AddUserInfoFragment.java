package com.experts.mysql;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddUserInfoFragment extends Fragment {
    private View sView;
    private String strName, strEmail, strPhone;
    private EditText edtName, edtEmail, edtPhone;
    private final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private Button btnSave;
    String SITE_KEY = "6LdEJywfAAAAAF6M33A6h9QG90vjyiSITxqGQCZZ";
    String SECRET_KEY = "6LdEJywfAAAAAJhXCNJvl-nT0lQ0NsBaKOBGHvjD";
    RequestQueue queue;
    private List<MainData> dataList;
    RoomDb database;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        sView = inflater.inflate(R.layout.fragment_add_user_info, container, false);
        queue = Volley.newRequestQueue(requireContext());
        findIds();
        setClicks();
        return sView;
    }


    private void verifyGoogleReCAPTCHA() {

        // below line is use for getting our safety
        // net client and verify with reCAPTCHA
        SafetyNet.getClient(requireContext()).verifyWithRecaptcha(SITE_KEY)
                // after getting our client we have
                // to add on success listener.
                .addOnSuccessListener(requireActivity(), new OnSuccessListener<SafetyNetApi.RecaptchaTokenResponse>() {
                    @Override
                    public void onSuccess(SafetyNetApi.RecaptchaTokenResponse response) {
                        // in below line we are checking the response token.
                        if (!response.getTokenResult().isEmpty()) {
                            // if the response token is not empty then we
                            // are calling our verification method.
                            handleVerification(response.getTokenResult());
                        }
                    }
                })
                .addOnFailureListener(requireActivity(), new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // this method is called when we get any error.
                        if (e instanceof ApiException) {
                            ApiException apiException = (ApiException) e;
                            // below line is use to display an error message which we get.
                            Log.d("TAG", "Error message: " +
                                    CommonStatusCodes.getStatusCodeString(apiException.getStatusCode()));
                        } else {
                            // below line is use to display a toast message for any error.
                            Toast.makeText(requireContext(), "Error found is : " + e, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    protected void handleVerification(final String responseToken) {
        // inside handle verification method we are
        // verifying our user with response token.
        // url to sen our site key and secret key
        // to below url using POST method.
        String url = "https://www.google.com/recaptcha/api/siteverify";

        // in this we are making a string request and
        // using a post method to pass the data.
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // inside on response method we are checking if the
                        // response is successful or not.
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("success")) {
                                // if the response is successful then we are
                                // showing below toast message.
//                                Toast.makeText(requireContext(), "Verified" + strEmail + " " + strName + " " + strPhone, Toast.LENGTH_SHORT).show();
                                setDataToSQL();

                            } else {
                                // if the response if failure we are displaying
                                // a below toast message.
                                Toast.makeText(requireContext(), String.valueOf(jsonObject.getString("error-codes")), Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception ex) {
                            // if we get any exception then we are
                            // displaying an error message in logcat.
                            Log.d("TAG", "JSON exception: " + ex.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // inside error response we are displaying
                        // a log message in our logcat.
                        Log.d("TAG", "Error message: " + error.getMessage());
                    }
                }) {
            // below is the getParams method in which we will
            // be passing our response token and secret key to the above url.
            @Override
            protected Map<String, String> getParams() {
                // we are passing data using hashmap
                // key and value pair.
                Map<String, String> params = new HashMap<>();
                params.put("secret", SECRET_KEY);
                params.put("response", responseToken);
                return params;
            }
        };
        // below line of code is use to set retry
        // policy if the api fails in one try.
        request.setRetryPolicy(new DefaultRetryPolicy(
                // we are setting time for retry is 5 seconds.
                10000,

                // below line is to perform maximum retries.
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        // at last we are adding our request to queue.
        queue.add(request);
    }

    private void setDataToSQL() {

        try {

            database = RoomDb.getInstance(requireContext());
            MainData mainData = new MainData();
            mainData.setEmail(strEmail);
            mainData.setName(strName);
            mainData.setPhone(strPhone);
            database.mainDaoUser().insert(mainData);
            Toast.makeText(requireContext(), "User Registered", Toast.LENGTH_SHORT).show();
            requireActivity().onBackPressed();
        } catch (Exception e) {

            Toast.makeText(requireContext(), "User not Registered" + e, Toast.LENGTH_SHORT).show();
            Log.i("EXCEPTION", " data " + e);
            Log.i("INFORMATION", "name" + strName + "phone" + strPhone + " email" + strEmail);
        }

    }

    private void setClicks() {

        btnSave.setOnClickListener(v -> {
            getData();
            if (strName.equalsIgnoreCase("")) {
                Toast.makeText(requireContext(), "Please Enter Valid Name", Toast.LENGTH_SHORT).show();

            } else if (!strEmail.matches(emailPattern)) {
                Toast.makeText(requireContext(), "Please Enter Valid Email", Toast.LENGTH_SHORT).show();
            } else if (strPhone.equals("")) {
                Toast.makeText(requireContext(), "Please Enter Valid Phone", Toast.LENGTH_SHORT).show();
            } else {
                verifyGoogleReCAPTCHA();
            }

        });

    }

    private void getData() {
        strEmail = edtEmail.getText().toString().trim();
        strPhone = edtPhone.getText().toString().trim();
        strName = edtName.getText().toString().trim();
    }

    private void findIds() {
        edtName = sView.findViewById(R.id.edtName);
        edtPhone = sView.findViewById(R.id.edtPhone);
        edtEmail = sView.findViewById(R.id.edtEmail);
        btnSave = sView.findViewById(R.id.btnSave);
    }


}