package com.experts.mysql;

import static androidx.room.OnConflictStrategy.REPLACE;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MainDaoUser {

    @Insert(onConflict = REPLACE)
    void insert(MainData mainData);

    @Query("SELECT * FROM users_data ORDER BY id ASC")
//    @Query("SELECT * FROM users_data")
    List<MainData> getAll();
}
