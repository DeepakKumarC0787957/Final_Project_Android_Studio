package com.experts.mysql;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainFragment extends Fragment implements MainAdapter.GetClick {
    private View sView;
    private TextView txtNoUsers;
    private CircularProgressIndicator mProgressBar;
    private RecyclerView rvUsersData;
    private List<MainData> dataList;
    private MainAdapter mainAdapter;
    private Button btnAddUser;
    RoomDb database;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        sView = inflater.inflate(R.layout.fragment_main, container, false);
        findIds();
        setAdapters();
        setClicks();
        return sView;
    }

    @Override
    public void onStart() {
        super.onStart();
//        setAdapters();
    }

    private void setAdapters() {

        database = RoomDb.getInstance(requireContext());
//        dataList.clear();
        dataList = database.mainDaoUser().getAll();
//        dataList.addAll(database.mainDaoUser().getAll());
        mainAdapter = new MainAdapter(dataList, requireActivity(), this);
        txtNoUsers.setVisibility(View.GONE);
        rvUsersData.setVisibility(View.GONE);

        new Handler().postDelayed(() -> {

            if (dataList.size() == 0) {
                txtNoUsers.setVisibility(View.VISIBLE);
                rvUsersData.setVisibility(View.GONE);
            } else {
                txtNoUsers.setVisibility(View.GONE);
                rvUsersData.setVisibility(View.VISIBLE);
            }
            mProgressBar.setVisibility(View.GONE);

        }, 2000);
        rvUsersData.setAdapter(mainAdapter);


    }

    private void findIds() {
        Snackbar.make(requireActivity().findViewById(android.R.id.content),
                "This is Demo Application Made By Maninder Singh", Snackbar.LENGTH_SHORT).show();
        btnAddUser = sView.findViewById(R.id.btnAddUser);
        mProgressBar = sView.findViewById(R.id.progress_bar);
        rvUsersData = sView.findViewById(R.id.rvUsersData);
        txtNoUsers = sView.findViewById(R.id.txtNoUsers);

    }

    private void setClicks() {
        btnAddUser.setOnClickListener(v -> Navigation.findNavController(v)
                .navigate(R.id.action_mainFragment_to_addUserInfoFragment));
    }


    @Override
    public void getClick(int position, String name, String phone, String email) {

        Bundle bundle = new Bundle();
        bundle.putString("name",name);
        bundle.putString("phone",phone);
        bundle.putString("email",email);
        Navigation.findNavController(sView).navigate(R.id.action_mainFragment_to_userInfoFragment,bundle);

    }
}