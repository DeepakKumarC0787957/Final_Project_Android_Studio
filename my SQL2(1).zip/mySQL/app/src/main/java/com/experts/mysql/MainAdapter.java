package com.experts.mysql;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {
    private List<MainData> dataList;
    private Activity context;
    private RoomDb roomDb;
    private GetClick click;

    public MainAdapter(List<MainData> dataList, Activity context, GetClick click) {
        this.dataList = dataList;
        this.context = context;
        this.click = click;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_users_list_items, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainData data = dataList.get(position);
        roomDb = RoomDb.getInstance(context);

        holder.txtPhone.setText(data.getPhone());
        holder.txtEmail.setText(data.getEmail());
        holder.txtName.setText(data.getName());

        holder.itemView.setOnClickListener(v -> {
            click.getClick(position, data.getName(), data.getPhone(), data.getEmail());
        });

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtName, txtPhone, txtEmail;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtEmail = itemView.findViewById(R.id.txtEmail);
            txtPhone = itemView.findViewById(R.id.txtPhone);
            txtName = itemView.findViewById(R.id.txtName);
        }
    }

    public interface GetClick {
        void getClick(int position, String name, String phone, String email);
    }
}
