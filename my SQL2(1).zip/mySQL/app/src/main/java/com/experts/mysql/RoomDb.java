package com.experts.mysql;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {MainData.class}, exportSchema = false, version = 1)
public abstract class RoomDb extends RoomDatabase {
    private static RoomDb roomDb;
    private static String DATABASE_NAME = "users_data";

    public static synchronized RoomDb getInstance(Context context) {

//        if (roomDb == null) {

        roomDb = Room.databaseBuilder(context.getApplicationContext(), RoomDb.class, DATABASE_NAME)
                .allowMainThreadQueries().fallbackToDestructiveMigration()
                .build();
//        }

        return roomDb;
    }


    public abstract MainDaoUser mainDaoUser();
}
